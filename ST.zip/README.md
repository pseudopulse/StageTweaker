# StageTweaker
Generates a configuration file for editing the properties of stages!
Configurations for interactable credits will generate after entering that stage.

# Changelog
## 1.1.3
- reverted 1.1.2
## 1.1.2
- updated BepInIncompatibility
## 1.1.1
- fixed bug where stages with a ' in their names failed to spawn interactables
## 1.1.0
- added config for interactable credits
- changed how stage pool configs are generated
- now able to change the stage 1 pool
## 1.0.0
- exists
