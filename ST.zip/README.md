# StageTweaker
Generates a configuration file for editing the properties of stages!
